13 original high-resolution in-game WEBP variants supplied by the user. No AI-generated or recolored icons.
Upload the assets/ folder into the root of WitcheEr-MHOutlanders/MhOutlanders-Builds.
The Builder mapping is already committed, with fallback to the previous icon sprite if a file is unavailable.
Color matching is provisional and should be visually checked against the PDF before declaring final accuracy.
